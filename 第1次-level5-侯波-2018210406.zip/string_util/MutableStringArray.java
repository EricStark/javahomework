package BItmap.com.eric.string_util;

public class MutableStringArray {

    Object[] objarr = null;
    Object[] empty = {};
    static int count = 0;
    static int initialCapacity = 0;
    /**
     * 在构造器中根据传入参数初始化数组
     * @param initialCapacity1
     */
    public MutableStringArray(int initialCapacity1){
        initialCapacity = initialCapacity1;
        if (initialCapacity > 0) {
            this.objarr = new Object[initialCapacity];
        } else if (initialCapacity == 0) {
            this.objarr = empty;
        } else {
            throw new IllegalArgumentException("Illegal Capacity: "+ initialCapacity);
        }
    }

    /**
     * 向数组末尾添加元素
     * @param s
     */
    public void add(String s){
        rangeCheck();
        objarr[count++] = s;
    }
    public boolean add(String[] s){
        rangeCheck();
        for (int i=0;i<s.length;i++){
            rangeCheck();
            objarr[count++] = s[i];
        }
        return true;
    }
    public boolean addAt(String s,int index){
        if (index>=count){
            throw new IndexOutOfBoundsException("写入index不合法");
        }
        rangeCheck();
        int move1 = count-1;
        int move2 = count;
        for (int i=0;i<count-index;i++){
            objarr[move2] = objarr[move1];//3=4;2=3;
            move2 -= 1;
            move1 -= 1;
        }
        objarr[index] = s;
        count++;
        return true;
    }
    public boolean deleteLast(){
        objarr[count-1] = null;
        count--;
        return true;
    }
    public boolean deleteAt(int index){
        int move1 = index;
        int move2 = index;
        for (int i=0;i<count-index-1;i++){
            objarr[move2] = objarr[++move1];
            move2++;
        }
        count--;
        return true;
    }
    public boolean clear(){
        for (int i=0;i<count;i++){
            objarr[i]  = null;
        }
        count = 0;
        return true;
    }
    public void changeAt(String s,int index){
        if (index>=count){
            throw new IndexOutOfBoundsException("index不合法");
        }
        objarr[index] = s;
    }
    public String get(int index){
        if (index>count){
            throw new IndexOutOfBoundsException("index不合法");
        }
        return (String) objarr[index];
    }
    public boolean contains(String s){
        for (int i=0;i<count;i++){
            if (objarr[i].equals(s)){
                return true;
            }
        }
        return false;
    }
    public int getLength(){
        return count;
    }

    /**
     * 检查是否越界
     * @return
     */
    public  void rangeCheck(){
        if (count>=initialCapacity){
           Object[] bigger = new Object[initialCapacity*2];
           for (int i=0;i<=count;i++){
               bigger[i] = objarr[i];
           }
           objarr = bigger;
        }
    }
}
