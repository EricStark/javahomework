package BItmap.com.eric.string_util;

public class StringUtil {
    public static void main(String[] args) {
        MutableStringArray mutableStringArray = new MutableStringArray(10);
        mutableStringArray.add("s");
        String[] strings = {"a","c","d"};
        mutableStringArray.add(strings);
        mutableStringArray.addAt("v",0);
        mutableStringArray.deleteLast();
        mutableStringArray.deleteAt(0);
        //mutableStringArray.clear();
        mutableStringArray.changeAt("m",0);
        System.out.println(mutableStringArray.get(1));
        System.out.println(mutableStringArray.contains("a"));
        System.out.println(mutableStringArray.getLength());
        for (int i=0;i<MutableStringArray.count;i++){
            System.out.println(mutableStringArray.objarr[i]);
        }
    }
}
